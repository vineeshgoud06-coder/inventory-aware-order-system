
# Inventory-Aware Order Processing System

## Project Overview

The Inventory-Aware Order Processing System is a full-stack web application that manages products, inventory, and customer orders. It uses a Spring Boot REST API for backend processing and a React frontend for user interaction.

The system validates product availability, calculates order totals on the server, reserves inventory during checkout, and supports payment failure simulation with transaction rollback.

## Features

- Product listing with prices and available stock
- Order checkout through REST APIs
- Server-side order total calculation
- Inventory validation and stock reservation
- Prevention of duplicate orders using idempotency keys
- Payment failure simulation
- Database transaction rollback on failed checkout
- Order and order-item persistence
- Product creation and order lookup
- H2 database integration

## Technology Stack

### Backend
- Java 17
- Spring Boot 3.3.5
- Spring Web
- Spring Data JPA
- Hibernate
- Maven
- H2 Database

### Frontend
- React
- Vite
- JavaScript
- HTML
- CSS

## Project Structure

```text
inventory-aware-order-system/
├── backend/
│   ├── src/
│   │   └── main/
│   │       ├── java/
│   │       │   └── com/mystartup/order/
│   │       │       ├── controller/
│   │       │       ├── dto/
│   │       │       ├── entity/
│   │       │       ├── repository/
│   │       │       └── service/
│   │       └── resources/
│   └── pom.xml
│
├── frontend/
│   ├── src/
│   ├── package.json
│   └── index.html
│
└── README.md
```

## Prerequisites

Install the following software before running the project:

- Java Development Kit (JDK) 17
- Apache Maven
- Node.js and npm
- Git

## Installation and Setup

### 1. Clone the Repository

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd inventory-aware-order-system
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with your actual GitHub repository URL.

### 2. Start the Backend

Open a terminal in the backend directory:

```bash
cd backend
mvn clean install
mvn spring-boot:run
```

The backend runs at:

http://localhost:8080

### 3. Start the Frontend

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the frontend URL shown in the terminal, usually:

http://localhost:5173

Keep both terminals running while using the application.

## Database Configuration

The application uses an H2 file-based database.

H2 Console:

http://localhost:8080/h2-console

Use these connection settings:

- JDBC URL: `jdbc:h2:file:./data/orders`
- Username: `sa`
- Password: Leave blank, unless configured differently

The database stores product and order information.

## API Endpoints

The following are the main API operations. Confirm the exact route mappings in your controller classes before submission.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/products` | Retrieve products |
| POST | `/api/checkout` | Place an order |
| GET | `/api/orders/{id}` | Retrieve an order by ID |
| POST | `/api/products` | Create a product |

### Example Checkout Request

**Endpoint:** `POST /api/checkout`

Header:

```text
Content-Type: application/json
Idempotency-Key: unique-order-key-001
```

Request body:

```json
{
  "items": [
    {
      "productId": 1,
      "quantity": 2
    }
  ],
  "simulatePaymentFailure": false
}
```

The backend calculates the total using database prices and checks stock before completing the order.

Use a new idempotency key for each new order.

## Business Logic

### Inventory Management

The application checks product availability before reserving stock. If stock is insufficient, checkout is rejected.

### Idempotency

An idempotency key identifies a checkout request. Repeating a request with the same key returns the existing order when one has already been saved.

### Payment Failure Simulation

The frontend provides a checkbox to simulate payment failure. When enabled, the checkout throws an exception and the database transaction rolls back the stock changes.

### Order Processing

For a successful checkout, the system calculates the total, reserves stock, creates the order and order items, and saves the transaction.

## Testing Checklist

- [ ] Products load correctly.
- [ ] Checkout succeeds when sufficient stock is available.
- [ ] Stock decreases after successful checkout.
- [ ] Checkout fails when stock is insufficient.
- [ ] Simulated payment failure restores stock.
- [ ] Repeated idempotency keys do not create duplicate orders.
- [ ] Order details are saved correctly.
- [ ] Product names appear correctly in order items.

## Future Enhancements

- User authentication and authorization
- Integration with a real payment gateway
- Product search and filtering
- Order history and order status tracking
- Automated unit and integration tests
- Deployment to a cloud platform

## Author

**Vineesh Goud**

## License

This project was developed for educational and demonstration purposes.
