
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const API = 'http://localhost:8080/api';

function App() {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [cart, setCart] = useState({});
  const [customer, setCustomer] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [fail, setFail] = useState(false);

  async function loadProducts() {
    try {
      const response = await fetch(`${API}/products`);
      if (!response.ok) throw new Error('Could not load products');
      setProducts(await response.json());
      setMessage('');
    } catch (error) {
      setMessage(
        'Cannot connect to backend. Make sure Spring Boot is running on port 8080.'
      );
    }
  }

  useEffect(() => {
    loadProducts();
  }, []);

  function change(id, quantity) {
    const product = products.find(p => p.id === id);
    if (!product) return;

    setCart(previous => ({
      ...previous,
      [id]: Math.max(0, Math.min(product.stock, Number(quantity) || 0))
    }));
  }

  async function checkout(event) {
    event.preventDefault();

    const items = Object.entries(cart)
      .filter(([, quantity]) => quantity > 0)
      .map(([productId, quantity]) => ({
        productId: Number(productId),
        quantity
      }));

    if (!items.length) {
      setMessage('Please add at least one product to your cart.');
      return;
    }

    setBusy(true);
    setMessage('');

    try {
      const response = await fetch(`${API}/checkout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': crypto.randomUUID()
        },
        body: JSON.stringify({
          items,
          simulatePaymentFailure: fail
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || data.error || 'Checkout failed');
      }

      setOrders(previous => [
        {
          id: data.id,
          status: data.status,
          totalAmount: data.totalAmount
        },
        ...previous
      ]);

      setMessage(
        `Order #${data.id} created successfully. Status: ${data.status}. Total: ${money(data.totalAmount)}`
      );

      setCart({});
      await loadProducts();
    } catch (error) {
      setMessage(error.message || 'Checkout failed. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function money(value) {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2
    }).format(Number(value) || 0);
  }

  const totalUnits = products.reduce((sum, product) => sum + product.stock, 0);
  const cartTotal = products.reduce(
    (sum, product) => sum + product.price * (cart[product.id] || 0),
    0
  );

  return (
    <main>
      <header>
        <div className="brand">S<span>F</span></div>
        <div>
          <p className="eyebrow">INVENTORY-AWARE COMMERCE</p>
          <h1>StockFlow</h1>
          <p className="sub">Order processing with stock protection built in.</p>
        </div>
        <button className="refresh" onClick={loadProducts}>Refresh</button>
      </header>

      {message && (
        <div className="notice">
          {message}
          <button onClick={() => setMessage('')}>×</button>
        </div>
      )}

      <section className="stats">
        <article><small>PRODUCTS</small><strong>{products.length}</strong></article>
        <article><small>UNITS IN STOCK</small><strong>{totalUnits}</strong></article>
        <article><small>ORDERS THIS SESSION</small><strong>{orders.length}</strong></article>
        <article>
          <small>PAID ORDERS THIS SESSION</small>
          <strong>{orders.filter(order => order.status === 'PAID').length}</strong>
        </article>
      </section>

      <div className="layout">
        <section className="panel">
          <div className="panelhead">
            <div>
              <p className="eyebrow">CATALOGUE</p>
              <h2>Available products</h2>
            </div>
            <span className="pill">{products.length} items</span>
          </div>

          <div className="products">
            {products.map(product => (
              <article className="product" key={product.id}>
                <div className="producticon">
                  {product.name.toLowerCase().includes('keyboard')
                    ? '⌨'
                    : product.name.toLowerCase().includes('hub')
                    ? '▣'
                    : '◉'}
                </div>
                <div className="productinfo">
                  <span className="sku">{product.sku}</span>
                  <h3>{product.name}</h3>
                  <strong>{money(product.price)}</strong>
                  <small>{product.stock} in stock</small>
                </div>
                <div className="qty">
                  <button
                    onClick={() => change(product.id, (cart[product.id] || 0) - 1)}
                    disabled={!cart[product.id]}
                  >−</button>
                  <span>{cart[product.id] || 0}</span>
                  <button
                    onClick={() => change(product.id, (cart[product.id] || 0) + 1)}
                    disabled={(cart[product.id] || 0) >= product.stock}
                  >+</button>
                </div>
              </article>
            ))}
            {products.length === 0 && (
              <p className="empty">Loading products or no products available.</p>
            )}
          </div>
        </section>

        <section className="panel checkout">
          <p className="eyebrow">SECURE CHECKOUT DEMO</p>
          <h2>Your order</h2>

          <form onSubmit={checkout}>
            <div className="cartlines">
              {products.filter(p => (cart[p.id] || 0) > 0).map(product => (
                <div className="cartline" key={product.id}>
                  <span>{product.name} × {cart[product.id]}</span>
                  <b>{money(product.price * cart[product.id])}</b>
                </div>
              ))}
              {!Object.values(cart).some(quantity => quantity > 0) && (
                <p className="empty">Your cart is empty. Add products to begin.</p>
              )}
            </div>

            <div className="total">
              <span>Order total</span>
              <strong>{money(cartTotal)}</strong>
            </div>

            <label className="check">
              <input
                type="checkbox"
                checked={fail}
                onChange={event => setFail(event.target.checked)}
              />
              Simulate payment failure
            </label>

            <button className="primary" disabled={busy || products.length === 0}>
              {busy ? 'Processing...' : 'Place order →'}
            </button>
            <p className="hint">
              Prices are verified by the backend. Stock is reserved during checkout.
            </p>
          </form>
        </section>
      </div>

      <section className="panel orderpanel">
        <div className="panelhead">
          <div>
            <p className="eyebrow">ACTIVITY</p>
            <h2>Recent orders</h2>
          </div>
          <span className="pill">{orders.length} this session</span>
        </div>

        {orders.length === 0 ? (
          <p className="empty">Your successful orders will appear here during this session.</p>
        ) : (
          <div className="tablewrap">
            <table>
              <thead>
                <tr><th>ORDER</th><th>TOTAL</th><th>STATUS</th></tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr key={order.id}>
                    <td>#{order.id}</td>
                    <td>{money(order.totalAmount)}</td>
                    <td>{order.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <footer>StockFlow · Inventory-aware order processing demo</footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
