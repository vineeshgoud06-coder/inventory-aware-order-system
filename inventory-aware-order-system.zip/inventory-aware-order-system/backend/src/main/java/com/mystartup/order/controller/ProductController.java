package com.mystartup.order.controller;

import com.mystartup.order.entity.Product;
import com.mystartup.order.service.OrderService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    private final OrderService orderService;

    public ProductController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public List<Product> getProducts() {
        return orderService.getProducts();
    }

    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        return orderService.createProduct(product);
    }
}