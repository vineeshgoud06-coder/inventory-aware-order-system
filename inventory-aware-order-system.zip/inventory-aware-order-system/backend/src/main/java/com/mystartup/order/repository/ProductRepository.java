package com.mystartup.order.repository;

import com.mystartup.order.entity.Product;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository
        extends JpaRepository<Product, Long> {

    boolean existsBySku(String sku);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Product p WHERE p.id = :id")
    Optional<Product> findByIdForUpdate(@Param("id") Long id);

    // Atomically reserve stock only when enough stock is available.
    @Modifying
    @Query("""
        UPDATE Product p
        SET p.stock = p.stock - :quantity
        WHERE p.id = :productId
          AND p.stock >= :quantity
        """)
    int reserveStock(
            @Param("productId") Long productId,
            @Param("quantity") int quantity
    );

    // Restore stock if a reservation must be reversed.
    @Modifying
    @Query("""
        UPDATE Product p
        SET p.stock = p.stock + :quantity
        WHERE p.id = :productId
        """)
    int restoreStock(
            @Param("productId") Long productId,
            @Param("quantity") int quantity
    );

    List<Product> findAllByOrderByIdAsc();
}