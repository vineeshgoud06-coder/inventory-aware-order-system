package com.mystartup.order.service;
import com.mystartup.order.dto.CreateProductRequest;
import com.mystartup.order.entity.Product;
import com.mystartup.order.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
@Service public class ProductService {
 private final ProductRepository repo; public ProductService(ProductRepository repo){this.repo=repo;}
 @Transactional(readOnly=true) public List<Product> all(){return repo.findAll();}
 @Transactional(readOnly=true) public Product get(Long id){return repo.findById(id).orElseThrow(()->new NoSuchElementException("Product not found: "+id));}
 @Transactional public Product create(CreateProductRequest r){if(repo.existsBySku(r.sku().trim())) throw new IllegalArgumentException("SKU already exists");return repo.save(new Product(r.name().trim(),r.sku().trim(),r.price(),r.stock()));}
 @Transactional public Product restock(Long id,int amount){if(amount<1||amount>100000)throw new IllegalArgumentException("Restock amount must be between 1 and 100000");Product p=repo.findByIdForUpdate(id).orElseThrow(()->new NoSuchElementException("Product not found: "+id));p.setStock(p.getStock()+amount);return p;}
}
