package com.mystartup.order.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.util.List;

public record CheckoutRequest(
    @NotEmpty List<@Valid Item> items,
    boolean simulatePaymentFailure
) {
    public record Item(
        @NotNull @Positive Long productId,
        @Positive int quantity
    ) {}
}