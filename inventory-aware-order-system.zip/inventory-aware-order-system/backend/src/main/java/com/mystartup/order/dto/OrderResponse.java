package com.mystartup.order.dto;

import com.mystartup.order.entity.CustomerOrder;
import com.mystartup.order.entity.OrderItem;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record OrderResponse(
        Long id,
        String status,
        BigDecimal totalAmount,
        LocalDateTime createdAt,
        List<ItemResponse> items
) {
    public record ItemResponse(
            Long productId,
            String productName,
            int quantity,
            BigDecimal unitPrice
    ) {}

    public static OrderResponse from(CustomerOrder order) {
        List<ItemResponse> items = order.getItems()
                .stream()
                .map(item -> new ItemResponse(
                        item.getProduct().getId(),
                        item.getProduct().getName(),
                        item.getQuantity(),
                        item.getUnitPrice()
                ))
                .toList();

        return new OrderResponse(
                order.getId(),
                order.getStatus(),
                order.getTotalAmount(),
                order.getCreatedAt(),
                items
        );
    }
}