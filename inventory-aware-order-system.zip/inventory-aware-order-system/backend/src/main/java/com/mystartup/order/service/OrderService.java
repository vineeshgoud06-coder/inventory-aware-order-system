
package com.mystartup.order.service;

import com.mystartup.order.dto.CheckoutRequest;
import com.mystartup.order.entity.CustomerOrder;
import com.mystartup.order.entity.OrderItem;
import com.mystartup.order.entity.Product;
import com.mystartup.order.repository.CustomerOrderRepository;
import com.mystartup.order.repository.ProductRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

@Service
public class OrderService {

    private final ProductRepository productRepository;
    private final CustomerOrderRepository orderRepository;

    public OrderService(
            ProductRepository productRepository,
            CustomerOrderRepository orderRepository) {
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
    }

    @Transactional
    public CustomerOrder checkout(
            CheckoutRequest request,
            String idempotencyKey) {

        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            throw new IllegalArgumentException(
                "Idempotency-Key header is required");
        }

        // Prevent duplicate orders for the same idempotency key.
        Optional<CustomerOrder> existing =
            orderRepository.findByIdempotencyKey(idempotencyKey);

        if (existing.isPresent()) {
            return existing.get();
        }

        if (request == null ||
                request.items() == null ||
                request.items().isEmpty()) {
            throw new IllegalArgumentException(
                "At least one item is required");
        }

        // Combine quantities when the same product appears more than once.
        Map<Long, Integer> quantities = new TreeMap<>();

        for (CheckoutRequest.Item item : request.items()) {
            if (item.productId() == null || item.quantity() <= 0) {
                throw new IllegalArgumentException(
                    "Product ID and positive quantity are required");
            }

            quantities.merge(
                item.productId(),
                item.quantity(),
                Math::addExact
            );
        }

        BigDecimal total = BigDecimal.ZERO;

        Map<Product, Integer> selectedProducts =
            new LinkedHashMap<>();

        // Validate products and calculate the total from database prices.
        for (Map.Entry<Long, Integer> entry : quantities.entrySet()) {

            Product product = productRepository
                .findById(entry.getKey())
                .orElseThrow(() -> new IllegalArgumentException(
                    "Product not found: " + entry.getKey()));

            if (product.getPrice() == null ||
                    product.getPrice().signum() < 0) {
                throw new IllegalStateException(
                    "Invalid product price");
            }

            selectedProducts.put(product, entry.getValue());

            BigDecimal itemTotal = product.getPrice().multiply(
                BigDecimal.valueOf(entry.getValue())
            );

            total = total.add(itemTotal);
        }

        // Reserve stock for each product.
        for (Map.Entry<Product, Integer> entry :
                selectedProducts.entrySet()) {

            Product product = entry.getKey();

            int updated = productRepository.reserveStock(
                product.getId(),
                entry.getValue()
            );

            if (updated != 1) {
                throw new IllegalStateException(
                    "Insufficient stock for product: " +
                    product.getName());
            }
        }

        // Simulate payment failure when requested.
        // The runtime exception rolls back stock changes.
        if (Boolean.TRUE.equals(request.simulatePaymentFailure())) {
            throw new PaymentFailedException(
                "Simulated payment failure; stock was restored");
        }

        CustomerOrder order = new CustomerOrder(
            idempotencyKey,
            "PAID",
            total
        );

        // Create order items with their product names.
        for (Map.Entry<Product, Integer> entry :
                selectedProducts.entrySet()) {

            Product product = entry.getKey();

            OrderItem orderItem = new OrderItem(
                product,
                entry.getValue(),
                product.getPrice()
            );

            order.addItem(orderItem);
        }

        return orderRepository.save(order);
    }

    @Transactional(readOnly = true)
    public List<Product> getProducts() {
        return productRepository.findAllByOrderByIdAsc();
    }

    @Transactional
    public Product createProduct(Product product) {

        if (product.getName() == null ||
                product.getName().isBlank()) {
            throw new IllegalArgumentException(
                "Product name is required");
        }

        if (product.getPrice() == null ||
                product.getPrice().signum() < 0) {
            throw new IllegalArgumentException(
                "Price cannot be negative");
        }

        if (product.getStock() < 0) {
            throw new IllegalArgumentException(
                "Stock cannot be negative");
        }

        return productRepository.save(product);
    }

    @Transactional(readOnly = true)
    public CustomerOrder getOrder(Long id) {
        return orderRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException(
                "Order not found: " + id));
    }
}
